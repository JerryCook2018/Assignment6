#include "pch.h"
#include "TwoThreeFourTree.h"


template<class ItemType>
TwoThreeFourTree<ItemType>::TwoThreeFourTree()
{
	rootPtr = nullptr;
}

template<class ItemType>
bool TwoThreeFourTree<ItemType>::add(const ItemType& newEntry)
{
	QuadNode<ItemType>* tempNode = rootPtr;
	QuadNode<ItemType>* newNodePtr(newEntry);

	//locate the leaf node the newEntry belongs in
	if (tempNode == nullptr)  //tree is empty
	{

		rootPtr = newNodePtr;
	}
	if (rootPtr->isLeaf()) //tree not empty only rootPtr
	{
		if (rootPtr->getSmallItem() == -1) // no items in root
		{
			rootPtr->setSmallItem(newEntry);
		}
		else if((rootPtr->getSmallItem() != -1)&&(rootPtr->getMiddleItem() ==-1)&&
			(rootPtr->getLargeItem() ==-1))     //place items in root
		{
			PlaceItemInNotFullNode(rootPtr, newEntry);
		}
		else //root already contains three item, split root then place entry 
		{
			QuadNode<ItemType> newRoot = split(QuadNode<ItemType>* rootPtr);
			rootPtr = newRoot;

			//find place to put newEntry after root has split
			QuadNode<ItemType>* findPlaceNode = rootPtr;

			//place entry where need to go
			if (newEntry > rootPtr->getSmallItem())  //move to right child, right is leaf, with small item filled.
			{
				findPlaceNode = rootPtr->getRightChildPtr();
				{
					if (newEntry > findPlaceNode->getSmallItem())
					{
						findPlaceNode->setLargeItem(newEntry);
					}

					else
						findPlaceNode->setSmallItem(newEntry);
				}
			}

			else // go to left node, left node is a leaf with only small item 
			{
				findPlaceNode = rootPtr->getLeftChildPtr();
				if (newEntry < findPlaceNode->getSmallItem())
				{
					findPlaceNode->setLargeItem(findPlaceNode->getSmallItem());
				}

				else
				{
					findPlaceNode->setLargeItem(newEntry);
				}

			}

		}

	}



	//if root node is a two node, has one data item in small, and two children
	else if (rootPtr->isTwoNode())
	{
		QuadNode<ItemType>* parentNode;
		tempNode = rootPtr;
		if (newEntry > tempNode->getSmallItem())
		{		
			//check if next node needs to be split before moving into it.
			if (tempNode->getRightChildPtr()->isFourNode())
			{
				ItemType oldMiddleItem = tempNode->getRightChildPtr()->getMiddleItem();

				QuadNode<ItemType>* nodeToSplit = tempNode->getRightChildPtr();
				splitRightNode(tempNode);
				//tempNode right child is now split to two nodes, right child middle item comes up to tempNode
				tempNode->setLargeItem(oldMiddleItem);
				if (newEntry < tempNode->getLargeItem())
				{
					parentNode = tempNode;
					tempNode = tempNode->getRightMidChildPtr();
				}
				else if (newEntry > tempNode->getLargeItem())
				{
					parentNode = tempNode;
					tempNode = tempNode->getRightChildPtr();
				}
			}

			//if tempNode is not a leaf//

			if (!tempNode->isLeaf())
			{
				while (!tempNode->isLeaf())
				{
					if (tempNode->isTwoNode())
					{
						if (newEntry < tempNode->getSmallItem())
						{
							parentNode = tempNode;
							if (tempNode->getLeftChildPtr()->isFourNode())
							{
								splitLeftNode(tempNode);
								if (newEntry < tempNode->getLeftChildPtr())
								{
									tempNode = tempNode->getLeftChildPtr();
								}
								else
								{
									tempNode = tempNode->getLeftMidChildPtr();
								}
							}
							tempNode = tempNode->getLeftChildPtr();

						}
						if (newEntry > tempNode->getSmallItem())
						{
							parentNode = tempNode();
							if (tempNode->getRightChildPtr()->isFourNode())
							{
								splitRightNode(parentNode);
								if (newEntry < tempNode->getLargeItem())
								{
									tempNode = tempNode->getRightMidChildPtr();
								}
								else
								{
									tempNode = tempNode->getRightChildPtr();
								}
							}
							tempNode = tempNode->getRightChild();
						}
					}
					else if (tempNode->isThreeNode)
					{
						if (newEntry < tempNode->getSmallItem())
						{
							tempNode = tempNode->getLeftChildPtr();

						}
						else if (newEntry > tempNode->getLargeItem())
						{
							tempNode = tempNode->getLargeItem();
						}
						else
						{
							tempNode = tempNode->getLeftMidChildPtr();
						}
					}
					
				}
			}
			else if (tempNode->isLeaf())
			{
				isLeafOperations(tempNode, newEntry);
			}
		}
		else if (newEntry < tempNode->getSmallItem())
		{
			tempNode = tempNode->getLeftChildPtr();
			if (tempNode->isLeaf())
			{
				isLeafOperations(tempNode, newEntry);
			}
		}
	}
}
	
template<class ItemType>
void TwoThreeFourTree<ItemType>::splitRightNode(QuadNode<ItemType>* tempNode)
{
	//get nodes children to move
	QuadNode<ItemType>* nodeBeforeSplit = tempNode->getRightChildPtr();
	QuadNode<ItemType>* oldLeftChild = nodeBeforeSplit->getLeftChildPtr();
	QuadNode<ItemType>* oldLeftMidChild = nodeBeforeSplit->getLeftMidChildPtr();
	QuadNode<ItemType>* oldRightMidChild = nodeBeforeSplit->getRightMidChildPtr();
	QuadNode<ItemType>* oldRightChild = nodeBeforeSplit->getRightChildPtr();


	// split node 
	rootPtr->setLargeItem(tempNode->getRightChildPtr()->getMiddleItem());
	rootPtr->setRightMidChildPtr(tempNode->getRightChildPtr()->getSmallItem());
	rootPtr->setRightChildPtr(tempNode->getRightChildPtr()->getLargeItem());

	//moves nodes 4 children
	rootPtr->getRightMidChildPtr()->setLeftChildPtr(oldLeftChild);
	rootPtr->getRightMidChildPtr()->setRightChildPtr(oldLeftMidChild);
	rootPtr->getRightChildPtr()->setLeftChildPtr(oldRightMidChild);
	rootPtr->getRightChildPtr()->setRightChildPtr(oldRightChild);
}
template <class ItemType>
void TwoThreeFourTree<ItemType>::isLeafOperations(QuadNode<ItemType>* tempNode, ItemType& newEntry)
{
	if ((tempNode->getMiddleItem() != -1) && (tempNode->getMiddleItem() != -1) &&
		(tempNode->getLargeItem() != -1))
	{
		//node needs to be split
	}
	else
	{
		PlaceItemInNotFullNode(tempNode, newEntry);
	}
}


template<class ItemType>
void TwoThreeFourTree<ItemType>::PlaceItemInNotFullNode(QuadNode<ItemType>* nodeToPlaceItemInPtr,
	ItemType& newEntry)
{
	//only one item in node in the small item spot.
	if((nodeToPlaceItemInPtr->getMiddleItem() == -1) && (nodeToPlaceItemInPtr->getLargeItem() == -1))
	{
		nodeToPlaceItemInPtr->setLargeItem(newEntry);
	}

	//two items in node one in small and one in large
	else if((nodeToPlaceItemInPtr->getSmallItem() != -1) && (nodeToPlaceItemInPtr->getMiddleItem() == -1) &&
		(nodeToPlaceItemInPtr->getLargeItem() != -1))
	{
		if (newEntry < nodeToPlaceItemInPtr->getSmallItem())
		{

			nodeToPlaceItemInPtr->setMiddleItem(nodeToPlaceItemInPtr->getSmallItem());
			nodeToPlaceItemInPtr->setSmallItem(newEntry);
		}
		else if (newEntry > nodeToPlaceItemInPtr->getLargeItem())
		{
			nodeToPlaceItemInPtr->setMiddleItem(nodeToPlaceItemInPtr->getLargeItem());
			nodeToPlaceItemInPtr->setLargeItem(newEntry);
		}
		else
		{
			nodeToPlaceItemInPtr->setMiddleItem(newEntry);
		}
	}
	
	
}

template<class ItemType>
QuadNode<ItemType>* TwoThreeFourTree<ItemType>::split(QuadNode<ItemType>* nodeToSplit)
{
	if(nodeToSplit == rootPtr)
	{
		
		QuadNode<ItemType>* newRootPtr(rootPtr->getMiddleItem());
		QuadNode<ItemType>* newLeftChildPtr(rootPtr->getSmallItem());
		QuadNode<ItemType>* newRightChildPtr(rootPtr->getLargeItem());

		rootPtr = newRootPtr;
		rootPtr->setLeftChildPtr(newLeftChildPtr);
		rootPtr->setRightChildPtr(newRightChildPtr);
	}
	else
	{
		QuadNode<ItemType>* newLeftChild(nodeToSplit->getSmallItem());
		QuadNode<ItemType>* newRightChild(nodeToSplit->getLargeItem());
		QuadNode<ItemType>* newNodeAfterSplit(nodeToSplit->getMiddleItem());
		newNodeAfterSplit->setLeftChildPtr(newLeftChild);
		newNodeAfterSplit->setRightChildPtr(newRightChild);
		return newNodeAfterSplit;

	}
}

//Henry S

template<class ItemType>
QuadNode<ItemType>* TwoThreeFourTree<ItemType>::findNode(QuadNode<ItemType>* treePtr, ItemType& entry) 
{
	if ((treePtr->getSmallItem() == entry) || (treePtr->getMidItem() == entry) || (treePtr->getLargeItem() == entry)) 
	{
		return treePtr;
	}

	else if (treePtr->isLeaf()) 
	{
		ItemType treeItem = nullptr;
		return treeItem;
	}

	else if (treePtr->isFourNode()) 
	{
		if (entry < treePtr->getSmallItem()) 
		{
			return findNode(treePtr->getLeftChildPtr(), entry);
		}

		else if ((entry > treePtr->getSmallItem()) && (entry < treePtr->getMidItem())) 
		{
			return findNode(treePtr->getLeftMidChildPtr(), entry);
		}

		else if ((entry > treePtr->getMidItem()) && (entry < treePtr->getLargeItem())) 
		{
			return findNode(treePtr->getRightMidChildPtr(), entry);
		}

		else if (entry > treePtr->getLargeItem()) 
		{
			return findNode(treePtr->getRightChildPtr(), entry);
		}
	}

	else if (treePtr->isThreeNode()) 
	{
		if (entry < treePtr->getSmallItem()) 
		{
			return findNode(treePtr->getLeftChildPtr(), entry);
		}

		else if (entry < treePtr->getLargeItem()) 
		{
			return findNode(treePtr->getLeftMidChildPtr(), entry);
		}

		else 
		{
			return findNode(treePtr->getRightChildPtr(), entry);
		}
	}

	else if (treePtr->isTwoNode()) 
	{
		if (entry < treePtr->getSmallItem()) 
		{
			return findNode(treePtr->getLeftChildPtr(), entry);
		}

		else 
		{
			return findNode(treePtr->getRightChildPtr(), entry);
		}
	}
}

template<class ItemType>
bool TwoThreeFourTree<ItemType>::removeItem(QuadNode<ItemType>* Ptr, const ItemType& entry)	//Henry S
{
	QuadNode<ItemType>* removeNode = findNode(Ptr, entry);
	QuadNode<ItemType>* tempNode = new QuadNode<ItemType>();

	if (removeNode == nullptr)
	{
		cout << "Entry not found. No entry deleted." << endl;
		return false;
	}

	else 
	{
		if (!removeNode->isLeaf()) {
			tempNode = removeNode; 
			while (!tempNode->isLeaf()) 
			{ 
				if (tempNode->isFourNode()) 
				{
					if (entry < tempNode->getSmallItem()) 
					{
						tempNode = tempNode->getLeftChildPtr();
					}

					else if ((entry > tempNode->getSmallItem()) && (entry < tempNode->getMidItem())) 
					{
						tempNode = tempNode->getLeftMidChildPtr();
					}

					else if ((entry > tempNode->getMidItem()) && (entry < tempNode->getLargeItem())) 
					{
						tempNode = tempNode->getRightMidChildPtr();
					}

					else if (entry > tempNode->getLargeItem()) 
					{
						tempNode = tempNode->getRightPtr();
					}
				}

				else if (tempNode->isThreeNode()) 
				{
					if (entry < tempNode->getSmallItem()) 
					{
						tempNode = tempNode->getLeftChildPtr();
					}

					else if (entry < tempNode->getLargeItem()) 
					{
						tempNode = tempNode->getLeftMidChildPtr();
					}

					else 
					{
						tempNode = tempNode->getRightChildPtr();
					}
				}

				else if (tempNode->isTwoNode()) 
				{
					if (entry < tempNode->getSmallItem()) 
					{
						tempNode = tempNode->getLeftChildPtr();
					}

					else 
					{
						tempNode = tempNode->getRightChildPtr();
					}
				}
			}

			if (removeNode->getSmallItem() == entry) 
			{ 
				ItemType temp = removeNode->getSmallItem();
				removeNode->setSmallItem(tempNode->getSmallItem);
				tempNode->setSmallItem(temp);
			}
			else if (removeNode->getMidItem() == entry) 
			{
				ItemType temp = removeNode->getMidItem();
				removeNode->setMidItem(tempNode->getSmallItem);
				tempNode->setSmallItem(temp);
			}

			else if (removeNode->getLargeItem() == entry) 
			{
				ItemType temp = removeNode->getLargeItem();
				removeNode->setLargeItem(tempNode->getSmallItem);
				tempNode->setSmallItem(temp);
			}


			if ((tempNode->getSmallItem() == entry) && (tempNode->getLargeItem() != NULL)) 
			{
				tempNode->setSmallItem(tempNode->getLargeItem());
				tempNode->setLargeItem(NULL);
			}

			else if ((tempNode->getLargeItem() == entry) && (tempNode->getMidItem() != NULL)) 
			{
				tempNode->setLargeItem(tempNode->getMidItem());
				tempNode->setMidItem(NULL);

			}

			else if ((tempNode->getLargeItem() == entry) && (tempNode->getMidItem() == NULL)) 
			{
				tempNode->setLargeItem(NULL);

			}

			else if ((tempNode->getMidItem() == entry)) 
			{
				tempNode->setMidItem(NULL);
			}

			else if (tempNode->getLargeItem() == NULL) 
			{

														 
				QuadNode<ItemType>* parentNode = tempNode->getParentPtr();
				QuadNode<ItemType>* mergeNode = new QuadNode<ItemType>();
				QuadNode<ItemType>* newNode = new QuadNode<ItemType>();

				if (parentNode->isFourNode()) 
				{
					if (tempNode == parentNode->getRightChildPtr) 
					{
						mergeNode == parentNode->getRightMidChildPtr();
						if (mergeNode->getLargeItem() != NULL) 
						{

						}
					}
				}
			}
		}
	}
	
}

template<class ItemType>
void TwoThreeFourTree<ItemType>::remove(const ItemType& entry)
{
	QuadNode<ItemType>* tempNode = rootPtr;

	removeItem(tempNode, entry);
}