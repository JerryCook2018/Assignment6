#pragma once
#include "pch.h"
#include "QuadNode.h"


template<class ItemType>
class TwoThreeFourTree
{
private:
	QuadNode<ItemType>* rootPtr;
	void PlaceItemInNotFullNode(QuadNode<ItemType>* nodeToPlaceItemInPtr, ItemType& newEntry);
	void isLeafOperations(QuadNode<ItemType>* tempNode, ItemType& newEntry);
	void splitRightNode(QuadNode<ItemType>* tempNode);
	bool removeItem(QuadNode<ItemType>* Ptr, const ItemType& entry);

public:
	TwoThreeFourTree();
	bool add(const ItemType& newEntry);
	void remove(const ItemType& entry);
	QuadNode<ItemType>* findNode(QuadNode<ItemType>* treePtr, ItemType& entry);
	QuadNode<ItemType>* split(QuadNode<ItemType>* nodeToSplit);

};
#include "TwoThreeFourTree.cpp"